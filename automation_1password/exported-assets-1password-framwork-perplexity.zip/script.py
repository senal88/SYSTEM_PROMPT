
# Create comprehensive structured data for the framework document
import json

framework_data = {
    "document_metadata": {
        "title": "Framework Customizado de Prompts Otimizados - 1Password no macOS Silicon",
        "version": "1.0",
        "target_audience": ["DevOps Engineers", "Security Engineers", "Software Architects", "Senior Developers"],
        "languages": ["pt-BR", "English (technical terms)"],
        "platform": "macOS Silicon (Apple M-series)",
        "date": "2025-10-24"
    },
    
    "master_prompts": {
        "prompt_1_cli_automation": {
            "name": "Automação Completa do 1Password CLI",
            "objective": "Configurar e automatizar o 1Password CLI v2 no macOS Silicon com Service Accounts",
            "technical_context": {
                "platform": "macOS Silicon (M1/M2/M3)",
                "cli_version": "1Password CLI 2.32.0+",
                "installation_method": "Homebrew (brew install --cask 1password-cli)",
                "authentication": ["Touch ID", "Apple Watch", "System Authentication"],
                "config_file": "~/.op/config",
                "service_account": "OP_SERVICE_ACCOUNT_TOKEN environment variable"
            },
            "structure": "Step-by-step with validation checkpoints",
            "dynamic_variables": [
                "{{service_account_token}}",
                "{{vault_name}}",
                "{{item_name}}",
                "{{op_account}}",
                "{{config_path}}"
            ],
            "example_commands": [
                "brew install --cask 1password-cli",
                "op --version",
                "export OP_SERVICE_ACCOUNT_TOKEN='ops_xxx...'",
                "op vault list",
                "op item list --vault={{vault_name}}",
                "op item get {{item_name}} --vault={{vault_name}} --fields label=password"
            ],
            "validation_steps": [
                "Verify CLI installation: op --version",
                "Check desktop integration: op signin",
                "Test Service Account: op whoami",
                "List accessible vaults: op vault list"
            ]
        },
        
        "prompt_2_cicd_integration": {
            "name": "Integração com CI/CD (GitHub Actions)",
            "objective": "Implementar automação segura de secrets em pipelines GitHub Actions",
            "technical_context": {
                "action": "1password/load-secrets-action@v3",
                "authentication": "OP_SERVICE_ACCOUNT_TOKEN via GitHub Secrets",
                "secret_reference_syntax": "op://vault/item/field",
                "masking": "Automatic secret masking in logs",
                "runners": "Ubuntu and macOS (not Windows)"
            },
            "structure": "YAML workflow template with security validation",
            "dynamic_variables": [
                "{{vault_name}}",
                "{{item_name}}",
                "{{field_name}}",
                "{{service_account_token}}",
                "{{env_file_path}}"
            ],
            "example_yaml": """
on: push
jobs:
  deploy:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      
      - name: Load secrets from 1Password
        id: load_secrets
        uses: 1password/load-secrets-action@v3
        env:
          OP_SERVICE_ACCOUNT_TOKEN: ${{ secrets.OP_SERVICE_ACCOUNT_TOKEN }}
          API_KEY: op://{{vault_name}}/{{item_name}}/api_key
          DATABASE_PASSWORD: op://{{vault_name}}/{{item_name}}/password
          
      - name: Deploy with secrets
        run: |
          echo "API Key loaded (masked): ${{ steps.load_secrets.outputs.API_KEY }}"
          ./deploy.sh
""",
            "best_practices": [
                "Store OP_SERVICE_ACCOUNT_TOKEN as GitHub Repository Secret",
                "Use secret references instead of plaintext",
                "Enable export-env: false for step outputs (recommended)",
                "Implement least privilege with dedicated vaults",
                "Monitor rate limits (10k read/1k write per hour for Business accounts)"
            ]
        },
        
        "prompt_3_agent_development": {
            "name": "Desenvolvimento de Agentes/Subagentes",
            "objective": "Orquestrar workflows complexos com automação inteligente baseada em secrets",
            "technical_context": {
                "languages": ["Python (onepassword-sdk)", "Node.js (@1password/sdk)", "Go (github.com/1password/onepassword-sdk-go)"],
                "architecture": "Microservices/Serverless Functions",
                "orchestration": "LLMs as decision makers",
                "secret_management": "SDK-based programmatic access"
            },
            "structure": "Agent architecture with decision flow",
            "dynamic_variables": [
                "{{integration_name}}",
                "{{integration_version}}",
                "{{secret_reference}}",
                "{{vault_id}}",
                "{{item_id}}"
            ],
            "example_python": """
import asyncio
import os
from onepassword.client import Client

async def agent_workflow():
    token = os.getenv('OP_SERVICE_ACCOUNT_TOKEN')
    client = await Client.authenticate(
        auth=token,
        integration_name='{{integration_name}}',
        integration_version='{{integration_version}}'
    )
    
    # Retrieve secret dynamically
    api_key = await client.secrets.resolve('{{secret_reference}}')
    
    # Agent decision logic
    if api_key:
        # Execute workflow with authenticated API
        result = await execute_api_call(api_key)
        return result
    else:
        raise ValueError('Secret not found')

if __name__ == '__main__':
    asyncio.run(agent_workflow())
""",
            "agent_patterns": [
                "Secret Resolver Agent: Fetches credentials dynamically",
                "Environment Provisioner: Sets up runtime environments",
                "Rotation Agent: Monitors and rotates secrets",
                "Compliance Agent: Audits secret access patterns"
            ]
        },
        
        "prompt_4_debugging_troubleshooting": {
            "name": "Debugging e Troubleshooting",
            "objective": "Diagnosticar e resolver problemas comuns do 1Password CLI no macOS",
            "technical_context": {
                "common_errors": [
                    "native messaging: LostConnectionToApp",
                    "connecting to desktop app: couldn't connect",
                    "Authentication failed",
                    "Rate limit exceeded",
                    "Service account token expired"
                ],
                "macos_specific": [
                    "Touch ID grayed out after migration",
                    "Homebrew symlink issues",
                    "Desktop app integration disabled"
                ]
            },
            "structure": "Decision tree with diagnostic checklist",
            "troubleshooting_tree": {
                "authentication_errors": {
                    "symptoms": "Error connecting to desktop app",
                    "checks": [
                        "Verify 1Password app is running",
                        "Check 'Integrate with 1Password CLI' is enabled in Settings > Developer",
                        "Confirm CLI binary location: which op (should be /usr/local/bin/op)",
                        "Restart 1Password app",
                        "Reset 1Password: Settings > Advanced > Reset 1Password"
                    ],
                    "solutions": [
                        "Update to latest 1Password app version (8.10.36+)",
                        "Reinstall CLI via .pkg installer instead of Homebrew",
                        "Delete and recreate ~/.op/config"
                    ]
                },
                "touch_id_issues": {
                    "symptoms": "Touch ID option grayed out",
                    "checks": [
                        "Verify Touch ID enabled in macOS System Settings",
                        "Check 'Use Touch ID for autofilling passwords' is enabled",
                        "Confirm Mac has Touch ID hardware or Magic Keyboard with Touch ID"
                    ],
                    "solutions": [
                        "Reset 1Password (Settings > Advanced > Reset 1Password)",
                        "Sign out and sign back in",
                        "Delete database: ~/Library/Group Containers/2BUA8C4S2C.com.1password/Library/Application Support/1Password/Data/1password.sqlite"
                    ]
                },
                "service_account_errors": {
                    "symptoms": "Service account authentication failed or rate limit exceeded",
                    "checks": [
                        "Verify OP_SERVICE_ACCOUNT_TOKEN is correctly set",
                        "Check token format: starts with 'ops_'",
                        "Confirm service account has vault access",
                        "Monitor rate limits: op service-account ratelimit"
                    ],
                    "solutions": [
                        "Rotate service account token",
                        "Upgrade to 1Password Business for higher limits (10k reads/hour)",
                        "Use Connect Server for unlimited requests",
                        "Implement caching strategy to reduce API calls"
                    ]
                }
            }
        },
        
        "prompt_5_security_compliance": {
            "name": "Segurança e Compliance",
            "objective": "Implementar hardening, auditoria e conformidade regulatória",
            "technical_context": {
                "security_principles": [
                    "Least Privilege",
                    "Secret Rotation",
                    "Access Auditing",
                    "Zero Trust Architecture"
                ],
                "compliance_frameworks": ["SOC 2", "GDPR", "ISO 27001", "HIPAA"],
                "encryption": "AES-256 with Two-Secret Key Derivation (2SKD)"
            },
            "structure": "Security checklist with compliance validation",
            "security_checklist": {
                "access_control": [
                    "✓ Service Accounts configured with vault-level restrictions",
                    "✓ No access to Personal, Private, or default Shared vaults",
                    "✓ Separate service accounts per environment (dev/staging/prod)",
                    "✓ Regular review of service account permissions"
                ],
                "secret_management": [
                    "✓ No plaintext secrets in code repositories",
                    "✓ All secrets use op:// reference syntax",
                    "✓ Environment files (.env) excluded from version control",
                    "✓ Secret masking enabled in CI/CD logs"
                ],
                "token_rotation": [
                    "✓ Service account tokens rotated every 90 days",
                    "✓ Automated rotation process documented",
                    "✓ Old tokens revoked immediately after rotation",
                    "✓ Token expiration monitoring alerts configured"
                ],
                "audit_logging": [
                    "✓ Service account activity monitored via 1Password admin console",
                    "✓ Failed authentication attempts logged",
                    "✓ API rate limit usage tracked",
                    "✓ Quarterly access reviews performed"
                ],
                "compliance_metrics": [
                    "✓ Mean Time to Rotate Secrets (MTRS) < 90 days",
                    "✓ Secret exposure incidents: 0",
                    "✓ Service account audit coverage: 100%",
                    "✓ Compliance policy adherence: 100%"
                ]
            }
        }
    },
    
    "secondary_prompts": [
        {
            "name": "Instalar 1Password CLI via Homebrew no macOS Silicon",
            "command": "brew install --cask 1password-cli",
            "validation": "op --version",
            "expected_output": "2.32.0 or later"
        },
        {
            "name": "Criar e Configurar Service Account",
            "steps": [
                "1. Access 1Password admin console",
                "2. Navigate to Integrations > Service Accounts",
                "3. Click 'Create Service Account'",
                "4. Select vaults to grant access (apply least privilege)",
                "5. Copy service account token (starts with 'ops_')",
                "6. Export token: export OP_SERVICE_ACCOUNT_TOKEN='ops_xxx'"
            ]
        },
        {
            "name": "Obter Campo Específico de Item",
            "command": "op item get {{item_name}} --vault={{vault_name}} --fields label={{field_label}}",
            "example": "op item get 'GitHub Token' --vault=Development --fields label=token"
        },
        {
            "name": "Listar Vaults Acessíveis",
            "command": "op vault list",
            "output_format": "ID, NAME columns"
        },
        {
            "name": "Rotacionar Token de Service Account",
            "process": [
                "1. Generate new service account token in admin console",
                "2. Update OP_SERVICE_ACCOUNT_TOKEN in all environments",
                "3. Test new token: op whoami",
                "4. Revoke old token in admin console",
                "5. Update CI/CD secrets (GitHub, GitLab, etc.)"
            ]
        },
        {
            "name": "Verificar Status de Autenticação",
            "command": "op whoami",
            "expected_output": "Service account email or user account info"
        },
        {
            "name": "Adicionar Secret a Item Existente",
            "command": "op item edit {{item_name}} --vault={{vault_name}} {{field_label}}={{new_value}}",
            "example": "op item edit 'API Keys' --vault=Production token[password]='new_token_value'"
        },
        {
            "name": "Usar Sintaxe op:// para Ler Secrets",
            "syntax": "op://{{vault}}/{{item}}/{{section}}/{{field}}",
            "examples": [
                "op://Production/AWS/credentials/access_key_id",
                "op://Development/Database/connection/password",
                "op://Personal/GitHub/token/api_key"
            ],
            "usage_with_op_read": "op read 'op://Production/AWS/credentials/access_key_id'",
            "usage_with_op_inject": "op inject -i config.yml.tpl -o config.yml",
            "usage_with_op_run": "op run --env-file=.env -- ./deploy.sh"
        },
        {
            "name": "Configurar Touch ID para CLI",
            "steps": [
                "1. Open 1Password app",
                "2. Go to Settings > Security",
                "3. Enable 'Touch ID'",
                "4. Go to Settings > Developer",
                "5. Enable 'Integrate with 1Password CLI'",
                "6. Test: op vault list (should prompt for Touch ID)"
            ]
        },
        {
            "name": "Injetar Secrets em Script com op run",
            "template_env_file": """# .env file with secret references
DATABASE_URL=op://Production/Database/connection/url
API_KEY=op://Production/API/credentials/key
JWT_SECRET=op://Production/Auth/secrets/jwt_secret""",
            "command": "op run --env-file=.env -- node app.js",
            "explanation": "op run scans environment variables, resolves secret references, and passes them to the subprocess"
        }
    ],
    
    "optimization_techniques": {
        "chain_of_thought": {
            "description": "Decompose complex tasks into sequential reasoning steps",
            "example": "To deploy with 1Password secrets: 1) Verify service account access, 2) Load secrets into environment, 3) Execute deployment script, 4) Validate deployment, 5) Clean up temporary secrets"
        },
        "few_shot_learning": {
            "description": "Provide examples to guide LLM responses",
            "example": "Example 1: op item get 'AWS' --vault=Prod --fields label=key\nExample 2: op item get 'GitHub' --vault=Dev --fields label=token\nNow execute: op item get '{{item_name}}' --vault={{vault_name}} --fields label={{field}}"
        },
        "role_based_prompting": {
            "description": "Assign specific roles to LLM for contextual responses",
            "example": "You are a DevOps engineer configuring 1Password CLI on macOS Silicon. Provide step-by-step instructions for setting up Service Accounts with least privilege access."
        },
        "context_injection": {
            "description": "Inject relevant context into prompts",
            "example": "Context: macOS Silicon M2, 1Password CLI 2.32.0, Service Account with Production vault access. Task: Retrieve database credentials and connect securely."
        },
        "constraint_based_prompting": {
            "description": "Apply constraints to guide LLM behavior",
            "example": "Constraint: Never output plaintext secrets. Always use op:// references or environment variable injection. Validate all commands before execution."
        },
        "output_format_specification": {
            "description": "Define exact output format",
            "example": "Output format: JSON with keys {command, expected_output, validation_steps}. Example: {\"command\": \"op vault list\", \"expected_output\": \"ID NAME\\n...\", \"validation_steps\": [\"Check exit code 0\"]}"
        }
    }
}

# Save to JSON for reference
with open('1password_framework_data.json', 'w', encoding='utf-8') as f:
    json.dump(framework_data, f, indent=2, ensure_ascii=False)

print("Framework data structure created successfully!")
print(f"\nTotal Master Prompts: {len(framework_data['master_prompts'])}")
print(f"Total Secondary Prompts: {len(framework_data['secondary_prompts'])}")
print(f"Total Optimization Techniques: {len(framework_data['optimization_techniques'])}")
