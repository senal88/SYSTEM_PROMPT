Text file: export_1password_env.sh
Latest content with line numbers:
1	#!/bin/bash
2	# =====================================================
3	# 🧩 export_1password_env.sh
4	# Script para exportar variáveis do 1Password e recriar o arquivo .env
5	# =====================================================
6	
7	# 🔐 Autenticação no 1Password
8	echo "🔑 Conectando ao 1Password CLI..."
9	op account add --address my.1password.com   --email "luiz.sena88@icloud.com"   --secret-key "A3-YEBP46-396NV5-RDFNK-7LCQK-A43DB-H4XKC"   --signin <<EOF
10	Gm@1L#Env@hard
11	EOF
12	
13	# ⚙️ Inicializa sessão ativa
14	eval $(op signin my.1password.com luiz.sena88@icloud.com)
15	
16	# 📥 Exporta item do vault
17	echo "📦 Exportando variáveis do vault 'vault_senamfo_local'..."
18	op item get "Google Cloud Credentials (.env.base64)"   --vault "vault_senamfo_local"   --format json | jq -r '.fields[] | "\(.label)=\(.value)"' > .env.base64
19	
20	# 🧩 Decodifica base64 e gera .env
21	echo "🧩 Decodificando variáveis..."
22	cat .env.base64 | while read line; do
23	  key=$(echo $line | cut -d '=' -f 1)
24	  val=$(echo $line | cut -d '=' -f 2-)
25	  echo "$key=$(echo $val | base64 --decode)" >> .env
26	done
27	
28	# ✅ Finalização
29	echo "✅ Arquivo .env recriado com sucesso a partir do vault 'vault_senamfo_local'."
30	